base - This is where we put the basic product definitions 
components - This is where we have one file for each component
layout - This is where we define the overall layout for each project 
pages - This is where we have we have specific styles for each pages of the project
themes - This is if we want to implement different themes for the same project
abstracts - This is where we put code that does not output any css like variables or mixins
vendors - This is for all thrid party css code